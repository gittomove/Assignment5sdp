###AdapterPatternOwnExample

##### Assignment SE2008 Yeerhan Aheti


This example is about musical instruments,which can tune voices and play something

- There is an interface "MusicalInstrument"
- Interface implemented by Dombra and GuitarAdapter concrete classes
- Also, another concrete class Guitar which has relation with GuitarAdapter
- Program execute in Main class which is class "InstrumentTest"