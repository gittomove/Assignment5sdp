public interface MusicalInstrument {
    void tuning();
    void play(String musicName);
}
