public class Guitar {

    public void tuning() {
        System.out.println("Tune 6 strings");
    }

    public void strum(String musicName){
        System.out.println("Strumming "+musicName+" on guitar");
    }
}
