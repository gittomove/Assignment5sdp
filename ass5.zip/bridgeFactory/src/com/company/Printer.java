package com.company;

public interface Printer {
    void print();
}
