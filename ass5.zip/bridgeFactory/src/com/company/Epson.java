package com.company;

public class Epson implements Printer{
    @Override
    public void print() {
        System.out.println("Epson print!");
    }
}
