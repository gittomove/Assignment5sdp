package com.company;

public class HP implements Printer{
    @Override
    public void print() {
        System.out.println("HP print!");
    }
}
