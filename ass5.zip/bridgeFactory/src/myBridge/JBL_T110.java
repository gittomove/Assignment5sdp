package myBridge;

public class JBL_T110 extends HeadPhones{


    public JBL_T110() {
        super("Wire");
    }

    @Override
    public void test() {
        System.out.println("JBL T110 is working...");
    }
}
